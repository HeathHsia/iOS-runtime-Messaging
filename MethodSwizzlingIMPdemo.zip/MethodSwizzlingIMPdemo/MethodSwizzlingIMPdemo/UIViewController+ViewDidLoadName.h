//
//  UIViewController+ViewDidLoadName.h
//  MethodSwizzlingIMPdemo
//
//  Created by 帝炎魔 on 16/5/12.
//  Copyright © 2016年 帝炎魔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (ViewDidLoadName)

@end
